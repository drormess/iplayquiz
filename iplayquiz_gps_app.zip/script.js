const requiredLat = 29.5;
const requiredLng = 34.9;
const radius = 0.05; // בק"מ (50 מטר)

function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
        0.5 - Math.cos(dLat)/2 + 
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
        (1 - Math.cos(dLon))/2;
    return R * 2 * Math.asin(Math.sqrt(a));
}

function checkLocation() {
    if (!navigator.geolocation) {
        document.getElementById("status").innerText = "מכשיר זה לא תומך ב-GPS.";
        return;
    }

    navigator.geolocation.getCurrentPosition((position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const distance = getDistanceFromLatLonInKm(lat, lng, requiredLat, requiredLng);

        if (distance <= radius) {
            document.getElementById("status").innerText = "הגעת למיקום הנכון! שאלה הבאה תיפתח.";
        } else {
            document.getElementById("status").innerText = `אתה רחוק ${distance.toFixed(2)} ק"מ מהמיקום.`;
        }
    }, () => {
        document.getElementById("status").innerText = "לא ניתן היה לאתר את המיקום.";
    });
}